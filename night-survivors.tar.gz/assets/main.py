"""Chinese classroom game. Rendering and input; the simulation lives in rules.py."""
import asyncio
import math
import os
import random
import sys
import json
from pathlib import Path
from functools import lru_cache
import pygame
from rules import World
from third_party_effects import DamageNumber, Particle, REFERENCE_FPS

ROOT = Path(__file__).resolve().parent
INK = (20, 27, 40)
PANEL = (32, 43, 59)
TEXT = (237, 235, 224)
MUTED = (152, 170, 186)
BLUE = (109, 184, 218)
GOLD = (225, 192, 123)
RED = (215, 105, 120)
MAX_PARTICLES = 112
MAX_DAMAGE_NUMBERS = 28


class Joystick:
    """Fixed, translucent thumb control. One captured finger; release means stop.

    Interaction concepts reviewed against nipplejs' static mode and threshold.
    This pygame implementation does not include nipplejs source or runtime code.
    """
    def __init__(self, width, height):
        self.center = pygame.Vector2(width - 76, height - 112)
        self.radius = 48
        self.knob_radius = 18
        self.offset = pygame.Vector2()
        self.finger = None
        self.deadzone = 0.16

    def begin(self, position, finger):
        if self.finger is None and pygame.Vector2(position).distance_to(self.center) <= self.radius + 22:
            self.finger = finger
            self.move(position, finger)
            return True
        return False

    def move(self, position, finger):
        if finger != self.finger:
            return
        self.offset = pygame.Vector2(position) - self.center
        if self.offset.length() > self.radius:
            self.offset.scale_to_length(self.radius)

    def release(self, finger=None):
        if finger is None or finger == self.finger:
            self.finger = None
            self.offset.update(0, 0)

    def direction(self):
        if self.finger is None or self.offset.length() / self.radius < self.deadzone:
            return pygame.Vector2()
        return self.offset.normalize()

    def draw(self, surface):
        size = 2 * (self.radius + self.knob_radius + 3)
        layer = pygame.Surface((size, size), pygame.SRCALPHA)
        c = pygame.Vector2(size / 2, size / 2)
        active = self.finger is not None
        pygame.draw.circle(layer, (167, 199, 216, 22 if not active else 36), c, self.radius)
        pygame.draw.circle(layer, (196, 218, 230, 60 if not active else 105), c, self.radius, 2)
        pygame.draw.circle(layer, (196, 218, 230, 36), c, 7, 1)
        for dx, dy in [(0, -1), (1, 0), (0, 1), (-1, 0)]:
            a = c + pygame.Vector2(dx, dy) * (self.radius - 6)
            b = c + pygame.Vector2(dx, dy) * (self.radius - 12)
            pygame.draw.line(layer, (209, 228, 235, 95), a, b, 2)
        pygame.draw.circle(layer, (184, 218, 232, 85 if not active else 135), c + self.offset, self.knob_radius)
        pygame.draw.circle(layer, (234, 244, 244, 130), c + self.offset, self.knob_radius, 1)
        surface.blit(layer, self.center - c)


class Game:
    def __init__(self, mobile=False):
        pygame.mixer.pre_init(22050, -16, 1, 512)
        pygame.init()
        self.world = World()
        self.w = self.world.config['screen']['width']
        self.h = self.world.config['screen']['height']
        self.surface = pygame.display.set_mode((self.w, self.h))
        pygame.display.set_caption('夜幕幸存者 · CDT501')
        self.clock = pygame.time.Clock()
        self.font_path = ROOT / 'fonts' / 'NotoSansSC-Regular.otf'
        self.mobile = mobile
        self.control_mode = 'touch' if mobile else 'auto'
        self.last_input = 'touch' if mobile else 'mouse'
        self.browser_window = None
        self.browser_qa = False
        if sys.platform == 'emscripten':
            try:
                import platform
                self.browser_window = platform.window
                # Prefer the primary pointer: a touch-capable laptop can still
                # be a keyboard/mouse device. Real touches switch auto mode later.
                self.mobile = mobile or bool(platform.window.matchMedia('(pointer: coarse)').matches)
                self.last_input = 'touch' if self.mobile else 'mouse'
                self.browser_qa = 'qa=1' in str(platform.window.location.search).lstrip('?').split('&')
            except (AttributeError, TypeError, ValueError):
                pass
        self.joy = Joystick(self.w, self.h)
        self.mouse = pygame.Vector2(self.w / 2, self.h / 2)
        self.mouse_enabled = False
        self.keyboard_mode = False
        self.keys = set()
        self.running = True
        self.muted = False
        self.audio_run_id = 0
        self._last_audio_state = None
        self.elapsed_ui = 0.0
        self.accumulator = 0.0
        self.particles = []
        self.damage_numbers = []
        self.effect_accumulator = 0.0
        self.shake = 0.0
        self.banner = ''
        self.banner_until = 0.0
        self.rng = random.Random(32)
        self.assets = {}
        for path in (ROOT / 'assets').glob('*.png'):
            if path.stem == 'asset-preview':
                continue
            self.assets[path.stem] = pygame.image.load(str(path)).convert_alpha()
        self.assets['demon_big'] = pygame.transform.scale_by(self.assets['demon'], 2)
        self.floor = self.assets['floor'].copy()
        self.floor.fill((47, 67, 103, 255), special_flags=pygame.BLEND_RGBA_MULT)
        self.sounds = {}
        if pygame.mixer.get_init():
            for name in ('hit', 'gem', 'levelup', 'hurt', 'victory', 'gameover'):
                for suffix in ('.ogg', '.wav'):
                    path = ROOT / 'sounds' / (name + suffix)
                    if path.exists():
                        try:
                            self.sounds[name] = pygame.mixer.Sound(str(path))
                            self.sounds[name].set_volume(0.55)
                        except pygame.error:
                            pass
                        break
        self.sound_times = {}
        self.pause_rect = pygame.Rect(self.w - 48, 62, 32, 32)
        self.sound_rect = pygame.Rect(self.w - 88, 62, 32, 32)
        self.start_rect = pygame.Rect(28, 520, self.w - 56, 56)
        self.restart_rect = pygame.Rect(42, 470, self.w - 84, 54)
        self.card_rects = [pygame.Rect(24, 210 + i * 120, self.w - 48, 102) for i in range(3)]
        self.smoke_stats = {'mouse_events': 0, 'finger_events': 0, 'max_joystick_distance': 0.0}

    @lru_cache(maxsize=16)
    def font(self, size):
        return pygame.font.Font(str(self.font_path), size)

    @lru_cache(maxsize=256)
    def glyph(self, text, size, color):
        return self.font(size).render(str(text), True, color)

    def label(self, text, pos, size=16, color=TEXT, center=False):
        pic = self.glyph(str(text), size, color)
        r = pic.get_rect(center=pos) if center else pic.get_rect(topleft=pos)
        self.surface.blit(pic, r)
        return r

    def paragraph(self, text, x, y, width, size=14, color=MUTED):
        line = ''
        for char in text:
            if char == '\n' or self.font(size).size(line + char)[0] > width:
                self.label(line, (x, y), size, color)
                y += size + 7
                line = '' if char == '\n' else char
            else:
                line += char
        if line:
            self.label(line, (x, y), size, color)
        return y + size + 7

    def button(self, rect, text, primary=True):
        hover = not self.mobile and rect.collidepoint(self.mouse)
        color = (211, 226, 224) if primary else PANEL
        if hover and primary:
            color = (233, 242, 232)
        pygame.draw.rect(self.surface, color, rect, border_radius=9)
        if not primary:
            pygame.draw.rect(self.surface, (71, 92, 113), rect, 1, border_radius=9)
        self.label(text, rect.center, 20, INK if primary else TEXT, center=True)

    def stop_movement(self):
        self.joy.release()
        self.keys.clear()
        self.mouse_enabled = False
        self.world.set_pointer(self.world.hero_x, self.world.hero_y, False)

    def set_control_mode(self, mode):
        if mode not in ('auto', 'touch', 'desktop') or mode == self.control_mode:
            return
        self.control_mode = mode
        self.stop_movement()
        self.keyboard_mode = False
        self.mobile = mode == 'touch' or (mode == 'auto' and self.last_input == 'touch')

    def select_input(self, source):
        """Auto mode follows real input, not SDL's synthetic touch mouse events."""
        self.last_input = source
        use_touch = self.control_mode == 'touch' or (self.control_mode == 'auto' and source == 'touch')
        if self.mobile != use_touch:
            self.stop_movement()
            self.keyboard_mode = False
            self.mobile = use_touch

    def pause_for_focus_loss(self):
        if self.world.phase == 'playing':
            self.world.toggle_pause()
        self.stop_movement()
        self.accumulator = 0

    def read_browser_control(self):
        if self.browser_window is None:
            return
        try:
            control = self.browser_window.nightSurvivorsControl
            self.set_control_mode(str(control.mode))
            if control.pauseRequested:
                control.pauseRequested = False
                self.pause_for_focus_loss()
        except (AttributeError, TypeError, ValueError):
            # The desktop build and the teacher's unmodified web shell need no bridge.
            pass

    def publish_browser_state(self):
        if self.browser_window is None:
            return
        self.browser_window.nightSurvivorsReady = True
        self.publish_audio_state()
        if self.browser_qa:
            self.browser_window.nightSurvivorsState = json.dumps({
                'phase': self.world.phase, 'elapsed': self.world.elapsed,
                'hero_x': self.world.hero_x, 'hero_y': self.world.hero_y,
                'mobile': self.mobile, 'joystick_active': self.joy.finger is not None,
                'joystick_offset': [self.joy.offset.x, self.joy.offset.y],
                'level': self.world.level, 'hp': self.world.hp, 'muted': self.muted,
                'invulnerable_remaining': self.world.invulnerable_remaining,
                'endless': self.world.endless, 'endless_wave': self.world.endless_wave,
                'choices': [{'id': card['id'], 'name': card['name']} for card in self.world.choices],
            }, ensure_ascii=True)

    def publish_audio_state(self):
        """Small production bridge; debug coordinates stay behind ?qa=1."""
        if self.browser_window is None:
            return
        state = json.dumps({'phase': self.world.phase, 'muted': self.muted,
                            'run_id': self.audio_run_id})
        if state != self._last_audio_state:
            self.browser_window.nightSurvivorsAudioState = state
            self._last_audio_state = state

    def toggle_mute(self):
        self.muted = not self.muted
        if self.muted and pygame.mixer.get_init():
            pygame.mixer.stop()
        self.publish_audio_state()

    def start(self):
        self.world.start()
        self.audio_run_id += 1
        self.particles.clear()
        self.damage_numbers.clear()
        self.effect_accumulator = 0.0
        self.accumulator = 0
        self.stop_movement()
        self.banner = '活到黎明，守住最后一束光'
        self.banner_until = self.elapsed_ui + 3

    def click(self, pos):
        """Return whether the UI consumed the press, so it cannot also move us."""
        phase = self.world.phase
        if phase in ('playing', 'paused', 'levelup') and self.sound_rect.collidepoint(pos):
            self.toggle_mute()
            return True
        if phase == 'title':
            if self.start_rect.collidepoint(pos):
                self.start()
            return True
        if phase in ('victory', 'gameover'):
            self.start()
            return True
        if phase == 'levelup':
            for i, rect in enumerate(self.card_rects):
                if rect.collidepoint(pos) and i < len(self.world.choices):
                    self.world.choose_card(i)
                    self.stop_movement()
                    self.accumulator = 0
                    return True
            return True
        if self.pause_rect.collidepoint(pos) or (phase == 'paused' and self.restart_rect.collidepoint(pos)):
            self.world.toggle_pause()
            self.stop_movement()
            self.accumulator = 0
            return True
        return phase == 'paused'

    def handle(self, event):
        if event.type == pygame.QUIT:
            self.running = False
        elif event.type == pygame.WINDOWFOCUSLOST:
            self.pause_for_focus_loss()
        elif event.type == pygame.KEYDOWN:
            self.select_input('keyboard')
            if event.key in (pygame.K_RETURN, pygame.K_SPACE) and self.world.phase in ('title', 'victory', 'gameover'):
                self.start()
            elif event.key in (pygame.K_p, pygame.K_ESCAPE):
                self.world.toggle_pause()
                self.stop_movement()
            elif event.key == pygame.K_m:
                self.toggle_mute()
            elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3) and self.world.phase == 'levelup':
                self.world.choose_card(event.key - pygame.K_1)
                self.stop_movement()
            elif event.key in (pygame.K_w, pygame.K_a, pygame.K_s, pygame.K_d, pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
                self.keyboard_mode = True
                self.keys.add(event.key)
        elif event.type == pygame.KEYUP:
            self.keys.discard(event.key)
        elif event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            self.smoke_stats['finger_events'] += 1
            if event.type == pygame.FINGERDOWN:
                self.select_input('touch')
            # SDL reports finger positions normalized to the canvas; CSS scaling
            # is handled by SDL. Do not scale them again with browser dimensions.
            pos = (event.x * self.w, event.y * self.h)
            if event.type == pygame.FINGERDOWN:
                consumed = self.click(pos)
                if not consumed and self.world.phase == 'playing' and self.mobile:
                    self.joy.begin(pos, event.finger_id)
            elif event.type == pygame.FINGERMOTION:
                self.joy.move(pos, event.finger_id)
            else:
                self.joy.release(event.finger_id)
        elif event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            self.smoke_stats['mouse_events'] += 1
            # SDL also emits mouse events for touches; handle the touch once.
            if getattr(event, 'touch', False):
                return
            self.select_input('mouse')
            self.mouse.update(event.pos)
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                consumed = self.click(event.pos)
                if not consumed and self.world.phase == 'playing' and self.mobile:
                    self.joy.begin(event.pos, 'mouse')
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                self.joy.release('mouse')
            elif event.type == pygame.MOUSEMOTION:
                if self.mobile:
                    self.joy.move(event.pos, 'mouse')
                else:
                    self.keyboard_mode = False
                    self.mouse_enabled = True

    def apply_input(self):
        w = self.world
        if w.phase != 'playing':
            w.set_pointer(w.hero_x, w.hero_y, False)
            return
        axis = pygame.Vector2()
        if self.mobile:
            axis = self.joy.direction()
        elif self.keyboard_mode:
            axis.x = bool(self.keys & {pygame.K_d, pygame.K_RIGHT}) - bool(self.keys & {pygame.K_a, pygame.K_LEFT})
            axis.y = bool(self.keys & {pygame.K_s, pygame.K_DOWN}) - bool(self.keys & {pygame.K_w, pygame.K_UP})
            if axis.length_squared():
                axis.normalize_ip()
        elif self.mouse_enabled:
            dx, dy = self.mouse.x - self.w / 2, self.mouse.y - self.h / 2
            w.set_pointer(w.hero_x + dx, w.hero_y + dy, self.mouse.y > 104 and self.mouse.y < self.h - 62)
            return
        w.set_pointer(w.hero_x + axis.x * 120, w.hero_y + axis.y * 120, axis.length_squared() > 0)

    def audio(self, name):
        if self.muted or name not in self.sounds:
            return
        gap = 0.055 if name in ('hit', 'gem') else 0.12
        if self.elapsed_ui - self.sound_times.get(name, -10) >= gap:
            self.sounds[name].play()
            self.sound_times[name] = self.elapsed_ui

    def collect_events(self):
        for e in self.world.drain_events():
            kind = e['type']
            if kind in ('hit', 'gem', 'levelup', 'hurt', 'victory', 'gameover'):
                self.audio(kind)
            if kind == 'hit':
                life = max(1, round(self.world.config['effects']['damage_number_seconds'] * REFERENCE_FPS))
                self.damage_numbers.append(DamageNumber(e['x'], e['y'] - 34, int(e['amount']), GOLD, life=life))
            elif kind == 'kill':
                life = max(1, round(self.world.config['effects']['death_flash_seconds'] * REFERENCE_FPS))
                # Reuse the upstream death burst's eight radial Particle objects.
                for _ in range(8):
                    self.particles.append(Particle(e['x'], e['y'], (174, 212, 217), speed=3, life=life))
            elif kind == 'hurt':
                self.shake = self.world.config['effects']['hurt_shake_seconds']
            elif kind == 'boss':
                self.banner = '深渊魔王再临！' if self.world.endless else '深渊魔王出现！坚持到黎明'
                self.banner_until = self.elapsed_ui + 3
            elif kind == 'endless':
                self.banner = '两分钟目标达成！无尽挑战开始'
                self.banner_until = self.elapsed_ui + 4
                self.audio('victory')
            elif kind == 'levelup':
                self.stop_movement()
                self.accumulator = 0
        self.particles = self.particles[-MAX_PARTICLES:]
        self.damage_numbers = self.damage_numbers[-MAX_DAMAGE_NUMBERS:]

    def update_effects(self, dt):
        """Keep the upstream 60 Hz damping independent of display refresh rate."""
        step = 1 / REFERENCE_FPS
        self.effect_accumulator += min(max(dt, 0), 0.1)
        while self.effect_accumulator + 1e-9 >= step:
            self.effect_accumulator = max(0.0, self.effect_accumulator - step)
            self.particles = [particle for particle in self.particles if particle.update()]
            self.damage_numbers = [number for number in self.damage_numbers if number.update()]

    def world_pos(self, x, y):
        return int(x - self.world.hero_x + self.w / 2 + self.offset[0]), int(y - self.world.hero_y + self.h / 2 + self.offset[1])

    def sprite(self, name, pos, scale=1):
        pic = self.assets[name]
        if scale != 1:
            pic = pygame.transform.scale_by(pic, scale)
        pygame.draw.ellipse(self.surface, (15, 24, 34), (pos[0] - 16 * scale, pos[1] + 13 * scale, 32 * scale, 9 * scale))
        self.surface.blit(pic, pic.get_rect(center=pos))

    def backdrop(self):
        tile = self.floor.get_width()
        ox = int(-self.world.hero_x + self.offset[0]) % tile
        oy = int(-self.world.hero_y + self.offset[1]) % tile
        for x in range(ox - tile, self.w, tile):
            for y in range(oy - tile, self.h, tile):
                self.surface.blit(self.floor, (x, y))
        # Sparse world-anchored stone markings keep movement readable.
        for gx in range(math.floor((self.world.hero_x - self.w) / 192), math.ceil((self.world.hero_x + self.w) / 192)):
            for gy in range(math.floor((self.world.hero_y - self.h) / 192), math.ceil((self.world.hero_y + self.h) / 192)):
                x, y = self.world_pos(gx * 192, gy * 192)
                pygame.draw.rect(self.surface, (39, 49, 63), (x, y, 23, 6))
                pygame.draw.rect(self.surface, (22, 32, 45), (x + 6, y + 6, 20, 4))

    def draw_world(self):
        w = self.world
        self.backdrop()
        hx, hy = self.world_pos(w.hero_x, w.hero_y)
        if w.ring_radius:
            layer = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
            radius = int(w.ring_radius)
            pygame.draw.circle(layer, (129, 198, 207, 18), (hx, hy), radius)
            pygame.draw.circle(layer, (156, 220, 225, 115), (hx, hy), radius, 2)
            self.surface.blit(layer, (0, 0))
        for gem in w.gems:
            p = self.world_pos(gem['x'], gem['y'])
            pic = self.assets['gem_blue' if gem['xp'] == 1 else 'gem_pink']
            pic = pygame.transform.scale(pic, (24, 24))
            self.surface.blit(pic, pic.get_rect(center=p))
        actors = [(e['y'], e) for e in w.enemies]
        actors.append((w.hero_y, None))
        for _, e in sorted(actors, key=lambda item: item[0]):
            if e is None:
                if w.invulnerable_remaining > 0:
                    shield = pygame.Surface((70, 70), pygame.SRCALPHA)
                    pygame.draw.circle(shield, (*GOLD, 35), (35, 35), 29)
                    pygame.draw.circle(shield, (*GOLD, 210), (35, 35), 29, 2)
                    self.surface.blit(shield, (hx - 35, hy - 35))
                pygame.draw.circle(self.surface, (106, 146, 171), (hx, hy + 9), 18, 1)
                self.sprite('hero', (hx, hy - int(math.sin(self.elapsed_ui * 8) * 1.2)))
                if w.invulnerable_remaining > 0:
                    self.label(f'无敌 {w.invulnerable_remaining:.1f} 秒', (hx, hy + 41), 13, GOLD, center=True)
            else:
                p = self.world_pos(e['x'], e['y'])
                if p[0] < -70 or p[0] > self.w + 70 or p[1] < -70 or p[1] > self.h + 70:
                    continue
                self.sprite('demon_big' if e['kind'] == 'demon' else e['kind'], p)
                if e['hp'] < e['max_hp']:
                    width = 46 if e['kind'] == 'demon' else 25
                    y = p[1] - (45 if e['kind'] == 'demon' else 24)
                    pygame.draw.rect(self.surface, (30, 31, 43), (p[0] - width // 2, y, width, 3))
                    pygame.draw.rect(self.surface, RED, (p[0] - width // 2, y, int(width * max(0, e['hp']) / e['max_hp']), 3))
        for b in w.blades:
            p = self.world_pos(b['x'], b['y'])
            angle = -math.degrees(math.atan2(b['y'] - w.hero_y, b['x'] - w.hero_x)) - 90
            pic = pygame.transform.rotate(self.assets['sword'], angle)
            self.surface.blit(pic, pic.get_rect(center=p))
        for shot in w.projectiles:
            p = self.world_pos(shot['x'], shot['y'])
            tail = (p[0] - shot['vx'] * 0.026, p[1] - shot['vy'] * 0.026)
            pygame.draw.line(self.surface, (126, 165, 170), tail, p, 3)
            pygame.draw.circle(self.surface, GOLD, p, 4)
            pygame.draw.circle(self.surface, (255, 249, 213), p, 2)
        cam_x = w.hero_x - self.w / 2 - self.offset[0]
        cam_y = w.hero_y - self.h / 2 - self.offset[1]
        for particle in self.particles:
            particle.draw(self.surface, cam_x, cam_y)
        for number in self.damage_numbers:
            number.draw(self.surface, cam_x, cam_y, self.font(14))

    @staticmethod
    def time_text(seconds):
        seconds = max(0, int(seconds + 0.00001))
        return f'{seconds // 60:02d}:{seconds % 60:02d}'

    def draw_hud(self):
        w = self.world
        layer = pygame.Surface((self.w, 104), pygame.SRCALPHA)
        layer.fill((*INK, 239))
        self.surface.blit(layer, (0, 0))
        pygame.draw.line(self.surface, (65, 82, 103), (16, 103), (self.w - 16, 103))
        self.label('生命', (18, 13), 13, MUTED)
        self.label(f'{math.ceil(max(0, w.hp))} / {int(w.max_hp)}', (72, 10), 17)
        self.label(f'等级 {w.level}', (18, 59), 14, BLUE)
        self.label(f'{w.xp} / {w.xp_needed}', (96, 61), 12, MUTED)
        for y, fraction, color, height in [(41, w.hp / w.max_hp, RED, 9), (84, min(1, w.xp / w.xp_needed), BLUE, 5)]:
            pygame.draw.rect(self.surface, (49, 62, 79), (18, y, 169, height), border_radius=3)
            pygame.draw.rect(self.surface, color, (18, y, max(0, int(169 * fraction)), height), border_radius=3)
        duration = w.config['goal']['duration_seconds']
        self.label(self.time_text(w.elapsed), (self.w - 94, 25), 25, TEXT, center=True)
        self.label('/ 无尽' if w.endless else '/ ' + self.time_text(duration), (self.w - 47, 27), 13, GOLD if w.endless else MUTED)
        self.label('静' if self.muted else '声', self.sound_rect.center, 15, MUTED, center=True)
        self.label('Ⅱ', self.pause_rect.center, 22, TEXT, center=True)
        for r in (self.sound_rect, self.pause_rect):
            pygame.draw.rect(self.surface, (69, 85, 106), r, 1, border_radius=7)
        foot = pygame.Surface((self.w, 56), pygame.SRCALPHA)
        foot.fill((*INK, 233));self.surface.blit(foot, (0, self.h - 56))
        inventory = []
        for key, level in w.weapons.items():
            inventory.append(w.config['weapons'][key]['short_name'] + str(level))
        for key, level in w.items.items():
            if level:
                inventory.append(w.config['items'][key]['short_name'] + str(level))
        self.label('  '.join(inventory), (15, self.h - 45), 13, TEXT)
        progress = f'击败 {w.kills}  ·  无尽第 {w.endless_wave} 波' if w.endless else f'击败 {w.kills}'
        self.label(progress, (15, self.h - 24), 12, GOLD if w.endless else MUTED)
        self.label('自动攻击', (self.w - 77, self.h - 24), 12, MUTED)
        if self.mobile and w.phase == 'playing':
            self.joy.draw(self.surface)
            self.label('移动', (self.joy.center.x, self.h - 50 - 2), 11, MUTED, center=True)
        elif w.phase == 'playing' and w.elapsed < 5:
            self.label('鼠标指向 · 或 WASD 移动', (self.w / 2, self.h - 85), 14, MUTED, center=True)
        if self.elapsed_ui < self.banner_until and w.phase == 'playing':
            self.label(self.banner, (self.w / 2, 128), 15, GOLD, center=True)

    def shade(self, alpha=210):
        layer = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        layer.fill((*INK, alpha));self.surface.blit(layer, (0, 0))

    def draw_title(self):
        self.backdrop()
        self.shade(176)
        pygame.draw.circle(self.surface, (172, 197, 203), (316, 88), 29)
        pygame.draw.circle(self.surface, INK, (329, 79), 27)
        self.label('夜幕', (29, 91), 42)
        self.label('幸存者', (29, 143), 42)
        self.label('守住最后一束光', (31, 213), 17, GOLD)
        pygame.draw.line(self.surface, (74, 93, 110), (31, 254), (359, 254))
        for angle in (0.4, 1.9, 3.6, 5.2):
            pos = (195 + math.cos(angle) * 104, 367 + math.sin(angle) * 66)
            self.sprite('bat', pos)
        pygame.draw.circle(self.surface, (72, 106, 133), (195, 367), 67, 1)
        pygame.draw.circle(self.surface, (43, 65, 88), (195, 367), 88, 1)
        self.sprite('hero', (195, 367), 1.6)
        self.label('先守住 120 秒', (195, 456), 26, BLUE, center=True)
        self.label('随后开启无尽挑战，持续成长', (195, 489), 14, MUTED, center=True)
        self.button(self.start_rect, '开始生存')
        controls = '右下摇杆移动，松手停止' if self.mobile else '鼠标指向移动，或使用 WASD / 方向键'
        self.label(controls, (195, 607), 13, TEXT, center=True)
        self.label('武器自动攻击 · 点击卡片升级', (195, 633), 13, MUTED, center=True)
        self.label('像素素材 Kenney · CC0', (195, 680), 11, MUTED, center=True)

    def card_icon(self, key, center):
        color = BLUE if key in self.world.config['weapons'] else GOLD
        pygame.draw.circle(self.surface, (48, 66, 85), center, 20)
        if key == 'spin_blades':
            pic = self.assets['sword'];self.surface.blit(pic, pic.get_rect(center=center))
        elif key == 'holy_ring':
            pygame.draw.circle(self.surface, BLUE, center, 13, 3)
        elif key in ('big_heart', 'heal'):
            self.label('心', center, 19, RED, center=True)
        elif key == 'magnet':
            pic = pygame.transform.scale(self.assets['gem_blue'], (28, 28));self.surface.blit(pic, pic.get_rect(center=center))
        elif key == 'swift_boots':
            self.label('风', center, 19, color, center=True)
        else:
            x, y = center;pygame.draw.polygon(self.surface, GOLD, [(x+2,y-15),(x-10,y+3),(x-1,y+3),(x-4,y+15),(x+11,y-4),(x+2,y-4)])

    def draw_levelup(self):
        self.shade(222)
        self.label('新的力量', (195, 120), 30, GOLD, center=True)
        self.label(f'已到达等级 {self.world.level}，选择一项成长', (195, 165), 15, MUTED, center=True)
        for index, (r, card) in enumerate(zip(self.card_rects, self.world.choices)):
            hover = not self.mobile and r.collidepoint(self.mouse)
            pygame.draw.rect(self.surface, (50, 69, 89) if hover else PANEL, r, border_radius=10)
            pygame.draw.rect(self.surface, (143, 175, 190) if hover else (68, 88, 111), r, 1, border_radius=10)
            self.card_icon(card['id'], (r.x + 34, r.y + 32))
            self.label(card['name'], (r.x + 65, r.y + 13), 19)
            new = '回复' if card['id'] == 'heal' else f'等级 {card["level"]}'
            self.label(new, (r.right - 68, r.y + 16), 13, GOLD)
            self.paragraph(card['description'], r.x + 20, r.y + 59, r.width - 40, 13, MUTED)
        self.label('战斗已暂停，慢慢选', (195, 614), 13, MUTED, center=True)

    def draw_end(self):
        self.shade(219)
        won = self.world.phase == 'victory'
        self.label('黎明已至' if won else '暂别夜幕', (195, 190), 34, GOLD if won else RED, center=True)
        subtitle = f'无尽挑战 · 第 {self.world.endless_wave} 波' if self.world.endless else ('你守住了最后一束光' if won else '再一次，把黑夜留在身后')
        self.label(subtitle, (195, 243), 15, MUTED, center=True)
        values = [('存活时间', self.time_text(self.world.elapsed)), ('击败敌人', str(self.world.kills)), ('最终等级', str(self.world.level))]
        for i, (title, value) in enumerate(values):
            y = 302 + i * 44
            self.label(title, (56, y), 16, MUTED)
            self.label(value, (278, y), 18, TEXT)
            pygame.draw.line(self.surface, (49, 66, 84), (56, y + 34), (334, y + 34))
        self.button(self.restart_rect, '再来一次')
        self.label('点击画面也可以重新开始', (195, 554), 13, MUTED, center=True)

    def draw(self):
        amp = self.world.config['effects']['hurt_shake_pixels'] if self.shake > 0 else 0
        self.offset = (self.rng.uniform(-amp, amp), self.rng.uniform(-amp, amp))
        if self.world.phase == 'title':
            self.draw_title()
        else:
            self.draw_world();self.draw_hud()
            if self.world.phase == 'levelup':
                self.draw_levelup()
            elif self.world.phase in ('victory', 'gameover'):
                self.draw_end()
            elif self.world.phase == 'paused':
                self.shade(220)
                self.label('歇一会儿', (195, 271), 32, center=True)
                self.label('时间停在这里，准备好再出发', (195, 325), 15, MUTED, center=True)
                self.button(self.restart_rect, '继续生存')
                self.label('也可以按 P 继续', (195, 552), 13, MUTED, center=True)
        pygame.display.flip()

    def frame(self, dt):
        self.read_browser_control()
        self.elapsed_ui += dt
        self.shake = max(0, self.shake - dt)
        self.update_effects(dt)
        self.apply_input()
        if self.world.phase == 'playing':
            self.accumulator += min(dt, 0.1)
            while self.accumulator >= self.world.STEP and self.world.phase == 'playing':
                self.world.update()
                self.accumulator -= self.world.STEP
                self.apply_input()
        else:
            self.accumulator = 0
        self.collect_events()
        self.draw()
        self.publish_browser_state()


async def main():
    smoke = '--smoke' in sys.argv
    app = Game(mobile='--mobile' in sys.argv or smoke)
    frame = 0
    release_pos = None
    smoke_result = {}
    while app.running:
        # The browser schedules asyncio frames; a blocking Clock delay would
        # occupy its event loop. Desktop still uses the configured frame cap.
        dt = app.clock.tick(0 if sys.platform == 'emscripten' else app.world.config['screen']['fps']) / 1000
        if smoke:
            dt = 1 / 60
            events = {
                0: pygame.event.Event(pygame.MOUSEMOTION, pos=(195, 540), rel=(0, 0), buttons=(0, 0, 0), touch=False),
                1: pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(195, 540), button=1, touch=False),
                3: pygame.event.Event(pygame.MOUSEBUTTONUP, pos=(195, 540), button=1, touch=False),
                10: pygame.event.Event(pygame.FINGERDOWN, x=(app.w-76)/app.w, y=(app.h-112)/app.h, finger_id=1, touch_id=1, pressure=1),
                12: pygame.event.Event(pygame.FINGERMOTION, x=(app.w-2)/app.w, y=(app.h-130)/app.h, finger_id=1, touch_id=1, pressure=1, dx=.1, dy=0),
                45: pygame.event.Event(pygame.FINGERUP, x=(app.w-2)/app.w, y=(app.h-130)/app.h, finger_id=1, touch_id=1, pressure=0),
                75: pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p),
                85: pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p),
            }
            if frame in events:
                pygame.event.post(events[frame])
        for event in pygame.event.get():
            app.handle(event)
        app.frame(dt)
        if smoke:
            app.smoke_stats['max_joystick_distance'] = max(app.smoke_stats['max_joystick_distance'], app.joy.offset.length())
            if frame == 44:
                smoke_result['joystick_moved_hero'] = math.hypot(app.world.hero_x, app.world.hero_y) > 20
            if frame == 46:
                release_pos = (app.world.hero_x, app.world.hero_y)
            if frame == 72:
                smoke_result['release_stops_hero'] = release_pos == (app.world.hero_x, app.world.hero_y)
            if frame == 76:
                smoke_result['pause_works'] = app.world.phase == 'paused'
            if frame >= 120:
                smoke_result.update(app.smoke_stats)
                smoke_result['joystick_is_clamped'] = app.smoke_stats['max_joystick_distance'] <= app.joy.radius + 0.001
                smoke_result['phase'] = app.world.phase
                smoke_result['pygame_version'] = pygame.version.ver
                (ROOT / 'evidence').mkdir(exist_ok=True)
                pygame.image.save(app.surface, str(ROOT / 'evidence' / 'smoke-mobile.png'))
                (ROOT / 'evidence' / 'input-smoke.json').write_text(json.dumps(smoke_result, ensure_ascii=False, indent=2), encoding='utf-8')
                print(json.dumps(smoke_result, ensure_ascii=False))
                app.running = False
        frame += 1
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == '__main__':
    asyncio.run(main())
