"""Deterministic Night Survivors rules, independent of pygame.

All tuning values live in data/game.json. Coordinates are world coordinates;
the renderer decides where the camera is. update() advances one fixed step.
"""
from __future__ import annotations

import copy
import json
import math
import random
from pathlib import Path

STEP = 1 / 60
EPS = 1e-9


def load_config():
    """Load the classroom's editable numbers and Chinese display names."""
    with (Path(__file__).resolve().parent / "data" / "game.json").open(encoding="utf-8") as stream:
        return json.load(stream)


class World:
    def __init__(self, config=None, seed=None):
        self.config = copy.deepcopy(load_config() if config is None else config)
        self.STEP = float(self.config["simulation"]["step_seconds"])
        self.rng = random.Random(seed)
        self._reset()
        self.phase = "title"

    def _reset(self):
        cfg = self.config
        self.phase = "playing"
        self.elapsed = 0.0
        self.endless = False
        self.endless_wave = 0
        self._next_endless_boss_at = cfg["goal"]["duration_seconds"] + cfg["endless"]["boss_first_delay_seconds"]
        self._invulnerable_until = 0.0
        self.hero_x = self.hero_y = 0.0
        self.hp = self.max_hp = float(cfg["hero"]["hp"])
        self.xp = 0
        self.level = 1
        self.kills = 0
        self.enemies = []
        self.projectiles = []
        self.gems = []
        self.weapons = {"spark_wand": 1}
        self.items = {key: 0 for key in cfg["items"]}
        self.choices = []
        self._events = []
        self._pointer = (0.0, 0.0, False)
        self._next_spawn = 0.0
        self._weapon_due = {key: 0.0 for key in cfg["weapons"]}
        self._blade_contacts = {}
        self._enemy_id = 0
        self._boss_spawned = False

    def start(self):
        """Start a fresh run, including a fresh survival milestone."""
        self._reset()

    @property
    def xp_needed(self):
        p = self.config["progression"]
        return int(p["xp_start"] + (self.level - 1) * p["xp_increment"])

    @property
    def invulnerable_remaining(self):
        """Seconds of upgrade protection left on the playing-time clock."""
        remaining = self._invulnerable_until - self.elapsed
        return remaining if remaining > EPS else 0.0

    @property
    def hero_speed(self):
        gain = self.config["items"]["swift_boots"]["per_level"]["speed_fraction"]
        return self.config["hero"]["speed"] * (1 + self.items.get("swift_boots", 0) * gain)

    @property
    def magnet_radius(self):
        gain = self.config["items"]["magnet"]["per_level"]["radius"]
        return self.config["hero"]["magnet_radius"] + self.items.get("magnet", 0) * gain

    @property
    def ring_radius(self):
        level = self.weapons.get("holy_ring", 0)
        if not level:
            return 0.0
        ring = self.config["weapons"]["holy_ring"]
        return ring["level1"]["radius"] + (level - 1) * ring["per_level"]["radius"]

    @property
    def blades(self):
        level = self.weapons.get("spin_blades", 0)
        if not level:
            return []
        cfg = self.config["weapons"]["spin_blades"]
        count = cfg["level1"]["blades"] + sum(level >= n for n in cfg["extra_blade_levels"])
        angle = self.elapsed / cfg["orbit_period"] * math.tau
        return [{"x": self.hero_x + math.cos(angle + i * math.tau / count) * cfg["orbit_radius"],
                 "y": self.hero_y + math.sin(angle + i * math.tau / count) * cfg["orbit_radius"]}
                for i in range(count)]

    @property
    def boss_spawned(self):
        return self._boss_spawned

    def set_pointer(self, world_x, world_y, active=True):
        self._pointer = (float(world_x), float(world_y), bool(active))

    def toggle_pause(self):
        if self.phase == "playing":
            self.phase = "paused"
        elif self.phase == "paused":
            self.phase = "playing"

    def drain_events(self):
        events, self._events = self._events, []
        return events

    def _emit(self, event_type, **values):
        self._events.append({"type": event_type, **values})

    def current_wave(self):
        if self.endless:
            cfg = self.config["endless"]
            return {"from": self.config["goal"]["duration_seconds"] + (self.endless_wave - 1) * cfg["wave_seconds"],
                    "types": cfg["enemy_types"],
                    "minimum": min(self.config["spawning"]["max_alive"],
                                   cfg["minimum_alive"] + (self.endless_wave - 1) * cfg["minimum_alive_gain_per_wave"])}
        selected = self.config["waves"][0]
        for wave in self.config["waves"]:
            if self.elapsed + EPS >= wave["from"]:
                selected = wave
            else:
                break
        return selected

    def _random_spawn_point(self):
        angle = self.rng.uniform(0, math.tau)
        radius = self.config["spawning"]["radius"]
        return self.hero_x + math.cos(angle) * radius, self.hero_y + math.sin(angle) * radius

    def spawn_enemy(self, kind, x=None, y=None):
        """Create one enemy, or return None when the global cap is reached."""
        if len(self.enemies) >= self.config["spawning"]["max_alive"]:
            return None
        if (kind == self.config["spawning"]["boss_kind"]
                and sum(e["kind"] == kind for e in self.enemies) >= self.config["endless"]["max_alive_bosses"]):
            return None
        stats = self.config["enemies"][kind]
        cfg = self.config["endless"]
        wave = self.endless_wave
        hp = float(stats["hp"]) * (1 + wave * cfg["enemy_hp_gain_per_wave"])
        speed_multiplier = min(cfg["enemy_speed_multiplier_cap"], 1 + wave * cfg["enemy_speed_gain_per_wave"])
        if x is None or y is None:
            x, y = self._random_spawn_point()
        self._enemy_id += 1
        enemy = {"id": self._enemy_id, "kind": kind, "x": float(x), "y": float(y),
                 "hp": hp, "max_hp": hp,
                 "speed": float(stats["speed"]) * speed_multiplier,
                 "damage": float(stats["damage"]) * (1 + wave * cfg["enemy_damage_gain_per_wave"]),
                 "contact_cooldown": float(stats["contact_cooldown"]), "endless_wave": wave,
                 "radius": float(stats["radius"]), "next_contact_at": 0.0}
        self.enemies.append(enemy)
        return enemy

    def damage_enemy(self, enemy, amount):
        """Apply one hit immediately, awarding a gem once when the enemy dies."""
        if enemy not in self.enemies or enemy["hp"] <= 0 or amount <= 0:
            return False
        amount = float(amount)
        enemy["hp"] -= amount
        self._emit("hit", amount=amount, x=enemy["x"], y=enemy["y"], kind=enemy["kind"])
        if enemy["hp"] <= 0:
            self.enemies.remove(enemy)
            self.kills += 1
            xp = self.config["enemies"][enemy["kind"]]["xp"]
            if xp > 0:
                self.gems.append({"x": enemy["x"], "y": enemy["y"], "xp": int(xp), "attracted": False})
            dead_id = enemy["id"]
            self._blade_contacts = {key: value for key, value in self._blade_contacts.items() if key[1] != dead_id}
            self._emit("kill", x=enemy["x"], y=enemy["y"], kind=enemy["kind"])
            return True
        return False

    def damage_hero(self, amount):
        """Apply player damage through one guard; blocked damage has no effects."""
        if self.phase != "playing" or amount <= 0 or self.invulnerable_remaining > 0:
            return False
        self.hp = max(0, self.hp - amount)
        self._emit("hurt", amount=amount, x=self.hero_x, y=self.hero_y)
        if self.hp <= 0:
            self.phase = "gameover"
            self._emit("gameover")
        return True

    def _try_spawn_boss(self):
        cfg = self.config["spawning"]
        if sum(e["kind"] == cfg["boss_kind"] for e in self.enemies) >= self.config["endless"]["max_alive_bosses"]:
            return None
        # Reserve one slot without exceeding the global enemy cap.
        if len(self.enemies) >= cfg["max_alive"]:
            normals = [e for e in self.enemies if e["kind"] != cfg["boss_kind"]]
            if normals:
                farthest = max(normals, key=lambda e: math.hypot(e["x"] - self.hero_x, e["y"] - self.hero_y))
                self.enemies.remove(farthest)
        boss = self.spawn_enemy(cfg["boss_kind"])
        if boss is not None:
            self._emit("boss", x=boss["x"], y=boss["y"], endless=self.endless, wave=self.endless_wave)
        return boss

    def _spawn_tick(self):
        cfg = self.config["spawning"]
        if not self._boss_spawned and self.elapsed + EPS >= cfg["boss_time"]:
            if self._try_spawn_boss() is not None:
                self._boss_spawned = True
        if self.endless and self.elapsed + EPS >= self._next_endless_boss_at:
            interval = max(self.STEP, self.config["endless"]["boss_interval_seconds"])
            # A missed check is skipped, not queued into a burst of bosses.
            passed = math.floor((self.elapsed - self._next_endless_boss_at + EPS) / interval) + 1
            self._next_endless_boss_at += passed * interval
            self._try_spawn_boss()
        if self.elapsed + EPS < self._next_spawn:
            return
        self._next_spawn = self.elapsed + cfg["interval"]
        wave = self.current_wave()
        amount = min(cfg["max_per_tick"], max(0, wave["minimum"] - len(self.enemies)),
                     max(0, cfg["max_alive"] - len(self.enemies)))
        for _ in range(int(amount)):
            self.spawn_enemy(self.rng.choice(wave["types"]))

    def _move_hero(self):
        x, y, active = self._pointer
        if not active:
            return
        dx, dy = x - self.hero_x, y - self.hero_y
        distance = math.hypot(dx, dy)
        deadzone = self.config["hero"]["pointer_deadzone"]
        if distance > deadzone:
            step = min(self.hero_speed * self.STEP, distance - deadzone)
            self.hero_x += dx / distance * step
            self.hero_y += dy / distance * step

    def _move_enemies(self):
        cfg = self.config["spawning"]
        hero_radius = self.config["hero"]["hit_radius"]
        for enemy in self.enemies[:]:
            stats = enemy  # Difficulty is a snapshot from this enemy's spawn wave.
            dx, dy = self.hero_x - enemy["x"], self.hero_y - enemy["y"]
            distance = math.hypot(dx, dy)
            if enemy["kind"] == cfg["boss_kind"]:
                if distance > cfg["boss_reposition_distance"]:
                    enemy["x"], enemy["y"] = self._random_spawn_point()
                    dx, dy = self.hero_x - enemy["x"], self.hero_y - enemy["y"]
                    distance = math.hypot(dx, dy)
            elif distance > cfg["despawn_distance"]:
                self.enemies.remove(enemy)
                continue
            if distance > EPS:
                step = min(stats["speed"] * self.STEP, distance)
                enemy["x"] += dx / distance * step
                enemy["y"] += dy / distance * step
            touching = math.hypot(self.hero_x - enemy["x"], self.hero_y - enemy["y"]) <= hero_radius + enemy["radius"]
            if (touching and self.elapsed + EPS >= enemy["next_contact_at"]
                    and self.damage_hero(stats["damage"])):
                enemy["next_contact_at"] = self.elapsed + stats["contact_cooldown"]
                if self.phase == "gameover":
                    return

    def _fire_sparks(self):
        level = self.weapons.get("spark_wand", 0)
        if not level or not self.enemies or self.elapsed + EPS < self._weapon_due["spark_wand"]:
            return
        cfg = self.config["weapons"]["spark_wand"]
        targets = sorted(self.enemies, key=lambda e: (e["x"] - self.hero_x) ** 2 + (e["y"] - self.hero_y) ** 2)
        sparks = cfg["level1"]["sparks"] + sum(level >= n for n in cfg["extra_spark_levels"])
        for i in range(int(sparks)):
            target = targets[i % len(targets)]
            dx, dy = target["x"] - self.hero_x, target["y"] - self.hero_y
            distance = math.hypot(dx, dy)
            ux, uy = (dx / distance, dy / distance) if distance > EPS else (1.0, 0.0)
            self.projectiles.append({"x": self.hero_x, "y": self.hero_y,
                                     "vx": ux * cfg["speed"], "vy": uy * cfg["speed"],
                                     "damage": cfg["level1"]["damage"] + (level - 1) * cfg["per_level"]["damage"],
                                     "ttl": cfg["projectile_lifetime"], "radius": cfg["projectile_radius"]})
        cooldown = cfg["level1"]["cooldown"] - (level - 1) * cfg["per_level"]["cooldown_reduction"]
        self._weapon_due["spark_wand"] = self.elapsed + max(self.STEP, cfg["minimum_cooldown"], cooldown)

    def _move_projectiles(self):
        active = []
        for projectile in self.projectiles:
            projectile["ttl"] -= self.STEP
            if projectile["ttl"] <= 0:
                continue
            old_x, old_y = projectile["x"], projectile["y"]
            projectile["x"] += projectile["vx"] * self.STEP
            projectile["y"] += projectile["vy"] * self.STEP
            dx, dy = projectile["x"] - old_x, projectile["y"] - old_y
            length2 = dx * dx + dy * dy
            collided = False
            for enemy in self.enemies[:]:
                # Segment collision also catches fast projectiles crossing a small enemy.
                fraction = 0 if length2 <= EPS else max(0, min(1, ((enemy["x"] - old_x) * dx + (enemy["y"] - old_y) * dy) / length2))
                hit_x, hit_y = old_x + fraction * dx, old_y + fraction * dy
                if math.hypot(hit_x - enemy["x"], hit_y - enemy["y"]) <= projectile.get("radius", self.config["weapons"]["spark_wand"]["projectile_radius"]) + enemy["radius"]:
                    self.damage_enemy(enemy, projectile["damage"])
                    collided = True
                    break
            if not collided:
                active.append(projectile)
        self.projectiles = active

    def _hit_with_blades(self):
        level = self.weapons.get("spin_blades", 0)
        if not level:
            return
        cfg = self.config["weapons"]["spin_blades"]
        amount = cfg["level1"]["damage"] + (level - 1) * cfg["per_level"]["damage"]
        for blade_index, blade in enumerate(self.blades):
            for enemy in self.enemies[:]:
                key = (blade_index, enemy["id"])
                if self.elapsed + EPS < self._blade_contacts.get(key, 0):
                    continue
                if math.hypot(blade["x"] - enemy["x"], blade["y"] - enemy["y"]) <= cfg["blade_radius"] + enemy["radius"]:
                    self._blade_contacts[key] = self.elapsed + cfg["hit_cooldown"]
                    self.damage_enemy(enemy, amount)

    def _hit_with_ring(self):
        level = self.weapons.get("holy_ring", 0)
        if not level or self.elapsed + EPS < self._weapon_due["holy_ring"]:
            return
        cfg = self.config["weapons"]["holy_ring"]
        amount = cfg["level1"]["damage"] + (level - 1) * cfg["per_level"]["damage"]
        for enemy in self.enemies[:]:
            if math.hypot(enemy["x"] - self.hero_x, enemy["y"] - self.hero_y) <= self.ring_radius + enemy["radius"]:
                self.damage_enemy(enemy, amount)
        self._weapon_due["holy_ring"] = self.elapsed + cfg["cooldown"]

    def _collect_gems(self):
        cfg = self.config["progression"]
        remaining = []
        for gem in self.gems:
            dx, dy = self.hero_x - gem["x"], self.hero_y - gem["y"]
            distance = math.hypot(dx, dy)
            if distance <= self.magnet_radius:
                gem["attracted"] = True
            if gem.get("attracted", False) and distance > EPS:
                step = min(cfg["gem_speed"] * self.STEP, distance)
                gem["x"] += dx / distance * step
                gem["y"] += dy / distance * step
                distance -= step
            if distance <= cfg["gem_collect_radius"]:
                self.xp += gem["xp"]
                self._emit("gem", x=gem["x"], y=gem["y"], amount=gem["xp"])
            else:
                remaining.append(gem)
        self.gems = remaining
        self._check_levelup()

    def _make_choices(self):
        progression = self.config["progression"]
        uncapped = self.endless and self.config["endless"]["uncapped_upgrades"]
        pool = []
        for weapon_id, cfg in self.config["weapons"].items():
            level = self.weapons.get(weapon_id, 0)
            if not uncapped and level >= progression["max_level"]:
                continue
            if not level and len(self.weapons) >= progression["max_weapons"]:
                continue
            next_level = level + 1
            description = cfg["description"] if not level else self._upgrade_description(weapon_id, next_level)
            pool.append({"id": weapon_id, "name": cfg["name"], "level": next_level,
                         "description": description, "kind": "weapon"})
        for item_id, cfg in self.config["items"].items():
            level = self.items.get(item_id, 0)
            if uncapped or level < progression["max_level"]:
                pool.append({"id": item_id, "name": cfg["name"], "level": level + 1,
                             "description": self._item_description(item_id), "kind": "item"})
        if not pool:
            pool = [{"id": "heal", "name": "月光疗愈", "level": 0,
                     "description": f"回复{progression['heal_fallback']:g}点生命", "kind": "heal"}]
        count = int(progression["card_count"])
        chosen = self.rng.sample(pool, min(count, len(pool)))
        # There are still three touch targets when only one or two upgrades remain.
        # Duplicates do not offer a maxed item or invent an unlisted reward.
        while len(chosen) < count:
            chosen.append(copy.deepcopy(chosen[len(chosen) % len(pool)]))
        self.choices = chosen

    def _item_description(self, item_id):
        """Keep card numbers accurate after a student edits the JSON tuning."""
        gain = self.config["items"][item_id]["per_level"]
        if item_id == "swift_boots":
            return f"移动速度提高{gain['speed_fraction'] * 100:g}%"
        if item_id == "big_heart":
            return f"生命上限+{gain['max_hp']:g}，回复{gain['heal']:g}"
        return f"经验吸取范围+{gain['radius']:g}像素"

    def _upgrade_description(self, weapon_id, next_level):
        cfg = self.config["weapons"][weapon_id]
        if weapon_id == "spark_wand":
            minimum = max(self.STEP, cfg["minimum_cooldown"])
            previous_cooldown = max(minimum, cfg["level1"]["cooldown"] - (next_level - 2) * cfg["per_level"]["cooldown_reduction"])
            next_cooldown = max(minimum, cfg["level1"]["cooldown"] - (next_level - 1) * cfg["per_level"]["cooldown_reduction"])
            reduction = previous_cooldown - next_cooldown
            text = f"伤害+{cfg['per_level']['damage']:g}"
            text += f"，间隔缩短{reduction:g}秒" if reduction > EPS else "，已达最快施放速度"
            if next_level in cfg["extra_spark_levels"]:
                text += "，星火+1"
            return text
        if weapon_id == "spin_blades":
            text = f"伤害+{cfg['per_level']['damage']:g}"
            if next_level in cfg["extra_blade_levels"]:
                text += "，刀刃+1"
            return text
        return f"伤害+{cfg['per_level']['damage']:g}，范围+{cfg['per_level']['radius']:g}"

    def _check_levelup(self):
        if self.phase != "playing" or self.xp < self.xp_needed:
            return False
        requirement = self.xp_needed
        self.xp -= requirement
        self.level += 1
        self.phase = "levelup"
        self._make_choices()
        self._emit("levelup", level=self.level)
        return True

    def choose_card(self, index):
        if self.phase != "levelup" or not isinstance(index, int) or not (0 <= index < len(self.choices)):
            return False
        card = self.choices[index]
        key = card["id"]
        if card["kind"] == "weapon":
            self.weapons[key] = card["level"]
            self._weapon_due[key] = self.elapsed
        elif card["kind"] == "item":
            self.items[key] = card["level"]
            if key == "big_heart":
                cfg = self.config["items"][key]["per_level"]
                self.max_hp += cfg["max_hp"]
                self.hp = min(self.max_hp, self.hp + cfg["heal"])
        else:
            self.hp = min(self.max_hp, self.hp + self.config["progression"]["heal_fallback"])
        protection = max(0.0, float(self.config["progression"]["post_upgrade_invulnerability_seconds"]))
        self._invulnerable_until = self.elapsed + protection
        self._emit("upgrade", id=key, name=card["name"], level=card["level"])
        self.choices = []
        self.phase = "playing"
        # Large XP gains may buy several levels; each gets its own paused choice.
        self._check_levelup()
        return True

    def update(self):
        """Advance exactly one fixed step only while playing."""
        if self.phase != "playing":
            return
        if self.hp <= 0:
            self.hp = 0
            self.phase = "gameover"
            self._emit("gameover")
            return
        duration = self.config["goal"]["duration_seconds"]
        self.elapsed += self.STEP
        if self.elapsed + EPS >= duration:
            entering = not self.endless
            self.endless = True
            wave_seconds = max(self.STEP, self.config["endless"]["wave_seconds"])
            self.endless_wave = 1 + math.floor(max(0.0, self.elapsed - duration + EPS) / wave_seconds)
            if entering:
                self._emit("endless", wave=self.endless_wave)
        self._move_hero()
        self._move_enemies()
        if self.phase != "playing":
            return
        self._spawn_tick()
        self._fire_sparks()
        self._move_projectiles()
        self._hit_with_blades()
        self._hit_with_ring()
        self._collect_gems()
