"""Particle and DamageNumber adapted from Vampire_Survivors-clone.

Upstream author / repository owner: yagizkoryurek
Repository: https://github.com/yagizkoryurek/Vampire_Survivors-clone
Commit: ecbde04dda74ad9380dbe0cb9f7c29a636739117
Source: main.py, lines 835-889 (Particle and DamageNumber)
License: MIT; original notice is in licenses/VampireSurvivors-clone-MIT.txt.

The original per-frame movement and damping are retained. Call update() at
REFERENCE_FPS, not once per rendered browser frame. Adaptations: target-surface
culling, configurable number lifetime, and cached number text. See
docs/open-source-reuse.md for the integration and attribution details.
"""

import math
import random

import pygame


REFERENCE_FPS = 60
C_YELLOW = (255, 230, 80)


class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life', 'color', 'size')

    def __init__(self, x, y, color, speed=2.0, size=4, life=30):
        self.x, self.y = float(x), float(y)
        angle = random.uniform(0, math.tau)
        s = random.uniform(speed * 0.4, speed)
        self.vx = math.cos(angle) * s
        self.vy = math.sin(angle) * s
        self.life = life
        self.max_life = life
        self.color = color
        self.size = size

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vx *= 0.92
        self.vy *= 0.92
        self.life -= 1
        return self.life > 0

    def draw(self, surf, cam_x, cam_y):
        t = self.life / self.max_life
        s = max(1, int(self.size * t))
        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        # Upstream uses SCREEN_W / SCREEN_H; our game has a portrait canvas.
        if -s < sx < surf.get_width() + s and -s < sy < surf.get_height() + s:
            pygame.draw.circle(surf, self.color, (sx, sy), s)


class DamageNumber:
    def __init__(self, x, y, value, color=C_YELLOW, life=50):
        self.x, self.y = float(x), float(y)
        self.vy = -1.5
        self.life = life
        self.max_life = life
        self.value = value
        self.color = color
        self._text = None

    def update(self):
        self.y += self.vy
        self.vy *= 0.95
        self.life -= 1
        return self.life > 0

    def draw(self, surf, cam_x, cam_y, font):
        alpha = max(0, min(255, int(self.life / self.max_life * 255)))
        # The value and font stay fixed for an effect. Render once on mobile.
        if self._text is None:
            self._text = font.render(str(self.value), True, self.color)
        self._text.set_alpha(alpha)
        surf.blit(self._text, (int(self.x - cam_x) - self._text.get_width() // 2,
                              int(self.y - cam_y)))
